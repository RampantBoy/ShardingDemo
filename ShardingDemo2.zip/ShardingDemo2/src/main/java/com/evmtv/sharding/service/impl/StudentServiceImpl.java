package com.evmtv.sharding.service.impl;

import com.evmtv.sharding.entity.Student;
import com.evmtv.sharding.mapper.StudentMapper;
import com.evmtv.sharding.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentMapper studentMapper;


    public boolean insert(Student student) {
        return studentMapper.insert(student) > 0 ? true :false;

    }
}
