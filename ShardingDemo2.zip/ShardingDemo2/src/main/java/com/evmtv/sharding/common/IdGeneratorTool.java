package com.evmtv.sharding.common;//package com.evmtv.sharding.common;

import org.springframework.stereotype.Service;
import org.springframework.util.IdGenerator;

public class IdGeneratorTool {

    public IdGenerator getIdGenerator() {
        //return new CommonSelfIdGenerator();
        return null;
    }

}
