package com.evmtv.sharding.controller;

import com.evmtv.sharding.entity.User;
import com.evmtv.sharding.service.StudentService;
import com.evmtv.sharding.service.UserService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/base")
public class BaseController {

    @Autowired
    private UserService userService;
    //http://localhost:8080/base/queryByUserID?ID=746832
    @RequestMapping(value = "queryByUserID", produces = "application/json")
    @ResponseBody
    public String queryByUserID(Integer ID) {
        JSONObject jsonObject = new JSONObject();
        if(ID==null){
            jsonObject.put("status", 500);
            jsonObject.put("msg", "ID is Empty");
            return jsonObject.toString();
        }

        List<Integer> list = new ArrayList<Integer>();
        list.add(ID);
        List<User> userList = userService.findByUserIds(list);
        if (userList.size() > 0) {
            jsonObject.put("status", 200);
            jsonObject.put("msg", "success");
            jsonObject.put("data", JSONArray.fromObject(userList).toString());
            int total = userService.countUser();
            jsonObject.put("total", total);

        } else {
            jsonObject.put("status", 500);
            jsonObject.put("msg", "No result");
        }
        return jsonObject.toString();

    }
}
