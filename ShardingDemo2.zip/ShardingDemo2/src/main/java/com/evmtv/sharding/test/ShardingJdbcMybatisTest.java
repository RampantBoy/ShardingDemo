package com.evmtv.sharding.test;

import com.evmtv.sharding.entity.Student;
import com.evmtv.sharding.entity.User;
import com.evmtv.sharding.service.StudentService;
import com.evmtv.sharding.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:webapp/WEB-INF/springmvc-servlet.xml",
        "file:webapp/WEB-INF/applicationContext.xml"})
public class ShardingJdbcMybatisTest {
    Logger log = LoggerFactory.getLogger(this.getClass());
    @Resource
    public UserService userService;

    @Resource
    public StudentService studentService;

    @Test
    public void testUserInsert() {
        for (int i = 0; i < 1; i++) {
            int math = (int) (Math.random() * 1000000);
            log.info("userID:{}", math);
            User u = new User();
            u.setUserId(math);
            u.setAge(25);
            u.setName("github");
            log.info("{}", u);
            Assert.assertEquals(userService.insert(u), true);
        }

    }

    @Test
    public void testUserUpdate() {
        User u = new User();
        u.setId(1146);
        u.setUserId(234234);
        u.setAge(44);
        u.setName("周文伟");
            Assert.assertEquals(userService.update(u), true);


    }


    @Test
    public void testStudentInsert() {
        int math = (int) (Math.random() * 1000000);
        log.info("studentID:{}", math);
        Student student = new Student();
        student.setStudentId(math);
        student.setAge(21);
        student.setName("hehe");
        Assert.assertEquals(studentService.insert(student), true);
    }

    @Test
    public void testFindAll() {
        List<User> users = userService.findAll();
        if (null != users && !users.isEmpty()) {
            for (User u : users) {
                System.out.println(u);
            }
        }
    }

    @Test
    public void testSQLIN() {
        List<User> users = userService.findByUserIds(Arrays.asList(494355, 10, 1));
        if (null != users && !users.isEmpty()) {
            for (User u : users) {
                System.out.println(u);
            }
        }
    }

    @Test
    public void testSQLdelete() {
        System.out.println( userService.delete(434986));
    }

    @Test
    public void testSQLcount() {
        System.out.println(userService.countUser());

    }

    @Test
    public void testSQLleft() {
        List<User> users = userService.findleft();
        if (null != users && !users.isEmpty()) {
            for (User u : users) {
                System.out.println(u);
            }
        }
    }

    @Test
    public void testTransactionTestSucess() {
        userService.transactionTestSucess();
    }

    @Test(expected = IllegalAccessException.class)
    public void testTransactionTestFailure() throws IllegalAccessException {
        userService.transactionTestFailure();
    }
}
