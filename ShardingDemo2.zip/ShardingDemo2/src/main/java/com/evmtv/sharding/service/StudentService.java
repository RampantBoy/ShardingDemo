package com.evmtv.sharding.service;

import com.evmtv.sharding.entity.Student;

public interface StudentService {
    boolean insert(Student student);


}
