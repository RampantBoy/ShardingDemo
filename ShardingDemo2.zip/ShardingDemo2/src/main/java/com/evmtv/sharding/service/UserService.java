package com.evmtv.sharding.service;

import com.evmtv.sharding.entity.User;

import java.util.List;

public interface UserService {
    public boolean insert(User u);

    public List<User> findAll();

    public List<User> findByUserIds(List<Integer> ids);

    public List<User> findleft();

    public int countUser();
    public int delete(Integer id);
    public boolean update(User u);
    public void transactionTestSucess();

    public void transactionTestFailure() throws IllegalAccessException;


}
